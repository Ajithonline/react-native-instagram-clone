import React, { PureComponent } from 'react'
import { Text, View ,StyleSheet,ScrollView} from 'react-native'

export class FeedScreen extends PureComponent {
    render() {
        return (
            <View style={styles.container}>
                
                <View style={styles.topBarWrapper}>
                   <Text>Top Bar</Text>
                   <Text>Top Bar</Text>
                   <Text>Top Bar</Text>
                </View>

                <ScrollView style={styles.scrollViewWrapper}>
                     <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>   
                     <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>
                    <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>   
                     <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>
                    <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>   
                     <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>
                    <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>   
                     <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>
                    <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>   
                     <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>
                    <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>   
                     <Text>SCrollview</Text>
                   <Text>SCrollview</Text> 
                   <Text>SCrollview</Text>
                    <Text>SCrollview</Text> 
                    <Text>SCrollview</Text>
                </ScrollView>

                <View style={styles.bottomBar}>
                   <Text>Bottom Bar</Text>
                   <Text>Bottom Bar</Text>
                   <Text>Bottom Bar</Text>
                   <Text>Bottom Bar</Text>
                   <Text>Bottom Bar</Text>
              
                </View>
            </View>
        )
    }
}

export default FeedScreen

export const styles=StyleSheet.create({
    container:{
        display:'flex',
     flex:1
    },
    topBarWrapper:{
        display:'flex',
        flexDirection:'row',
        justifyContent:'space-between'
    },
    bottomBar:{
         display:'flex',
         flexDirection:'row',
         justifyContent:'space-between',
         backgroundColor:'red',
         position:'absolute',
         bottom:0,
         height:40  ,
         width:'100%'
    
    },
    scrollViewWrapper:{
        display:'flex'
    }
})